# pca-pwa
`pca-pwa`, a simplified manner for insights and decision-making, by visualizing complex relationships with PCA web application

### The Purpose of the Package
- The purpose of the package is to offer a simple way of visualizing relatationships between items of any given dataset. 
The user could easily obtain a pca plot without needing to configure or compile the application.


